"""
UNIT 77 MBR SUPER EXPERT — CONFIGURATION & CONSTANTS
Defines physical constants, plant topology, operational thresholds, and default telemetry.
"""

from typing import Dict, Any

# Standard Physical Constants
PHYSICAL_CONSTANTS: Dict[str, Any] = {
    "WATER_DENSITY_KG_M3": 1000.0,
    "STANDARD_TEMP_C": 20.0,
    "GRAVITY_M_S2": 9.80665,
    "BAR_TO_KPA": 100.0,
    "KPA_TO_PA": 1000.0,
    "SECONDS_PER_HOUR": 3600.0,
    "HOURS_PER_DAY": 24.0,
    "LMH_TO_M_S": 1.0 / 3600000.0,  # L/(m^2*h) -> m/s
    "KG_TO_MG": 1e6,
    "M3_TO_L": 1000.0,
}

# Unit 77 Plant Physical Topology
PLANT_CONFIG: Dict[str, Any] = {
    "NAME": "Unit 77 Industrial MBR Facility",
    "TOTAL_TRAINS": 4,
    "TRAIN_IDS": ["A", "B", "C", "D"],
    "MEMBRANE_AREA_PER_TRAIN_M2": 4800.0,
    "TOTAL_MEMBRANE_AREA_M2": 19200.0,
    "MEMBRANE_TYPE": "PVDF Hollow Fiber Ultrafiltration",
    "PORE_SIZE_MICRON": 0.04,
    "BIOLOGICAL_REACTOR_VOLUME_M3": 3200.0,  # Anoxic + Aerobic Basins
    "MBR_TANKS_VOLUME_M3": 800.0,  # Membrane Tanks (4x 200 m3)
    "TOTAL_PLANT_VOLUME_M3": 4000.0,
    "CYCLE_FILTRATION_TIME_MIN": 9.0,
    "CYCLE_BACKWASH_TIME_MIN": 0.75,
    "CYCLE_RELAXATION_TIME_MIN": 0.25,
    "TOTAL_CYCLE_TIME_MIN": 10.0,
    "FILTRATION_DUTY_RATIO": 0.90,  # 9.0 / 10.0
}

# Operational Envelope & Safety Thresholds
OPERATIONAL_LIMITS: Dict[str, Any] = {
    "TMP_NOMINAL_MAX_KPA": 35.0,
    "TMP_MAINTENANCE_CLEAN_KPA": 45.0,
    "TMP_EMERGENCY_STOP_KPA": 55.0,
    "TMP_RATE_OF_CHANGE_ALERT_KPA_H": 0.35,
    "TMP_RATE_OF_CHANGE_ALARM_KPA_H": 0.50,
    "FLUX_SUSTAINABLE_MAX_LMH": 30.0,
    "FLUX_DESIGN_AVERAGE_LMH": 24.0,
    "PERMEABILITY_LOW_ALERT_LMH_BAR": 120.0,
    "PERMEABILITY_LOW_ALARM_LMH_BAR": 90.0,
    "MIN_SRT_NITRIFICATION_DAYS": 12.0,
    "TARGET_SRT_DAYS": 25.0,
    "MAX_SRT_DAYS": 90.0,
    "TARGET_MLSS_MG_L": 8500.0,
    "MAX_MLSS_MG_L": 12000.0,
}

# Individual Train Engineering Specification
TRAINS_CONFIG: Dict[str, Dict[str, Any]] = {
    "A": {
        "id": "A",
        "name": "Train A (Primary)",
        "area_m2": 4800.0,
        "clean_tmp_kpa": 10.0,
        "clean_flux_lmh": 24.0,
        "clean_temp_c": 20.0,
        "clean_rm_m_inv": 1.497e12,
    },
    "B": {
        "id": "B",
        "name": "Train B (Secondary)",
        "area_m2": 4800.0,
        "clean_tmp_kpa": 10.0,
        "clean_flux_lmh": 24.0,
        "clean_temp_c": 20.0,
        "clean_rm_m_inv": 1.497e12,
    },
    "C": {
        "id": "C",
        "name": "Train C (High-Foul Stress)",
        "area_m2": 4800.0,
        "clean_tmp_kpa": 10.0,
        "clean_flux_lmh": 24.0,
        "clean_temp_c": 20.0,
        "clean_rm_m_inv": 1.497e12,
    },
    "D": {
        "id": "D",
        "name": "Train D (Standby/Backup)",
        "area_m2": 4800.0,
        "clean_tmp_kpa": 10.0,
        "clean_flux_lmh": 24.0,
        "clean_temp_c": 20.0,
        "clean_rm_m_inv": 1.497e12,
    },
}

# Default Operating Telemetry (Matching Excel Sheet 02 & 04)
DEFAULT_TELEMETRY: Dict[str, Any] = {
    "temperature_c": 18.5,
    "flow_train_a_m3_h": 115.2,
    "flow_train_b_m3_h": 115.2,
    "flow_train_c_m3_h": 115.2,
    "flow_train_d_m3_h": 115.2,
    "total_flow_m3_h": 460.8,
    "tmp_train_a_kpa": 18.6,
    "tmp_train_b_kpa": 19.8,
    "tmp_train_c_kpa": 27.5,
    "tmp_train_d_kpa": 18.2,
    "slope_train_a_kpa_h": 0.12,
    "slope_train_b_kpa_h": 0.18,
    "slope_train_c_kpa_h": 0.42,
    "slope_train_d_kpa_h": 0.08,
    "mlss_bioreactor_mg_l": 8200.0,
    "mlss_mbr_tanks_mg_l": 9500.0,
    "was_flow_m3_d": 35.0,
    "effluent_tss_mg_l": 1.5,
    "influent_bod_mg_l": 240.0,
    "aeration_flow_nm3_h": 420.0,
}
